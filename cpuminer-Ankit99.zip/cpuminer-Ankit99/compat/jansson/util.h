/*
 * Copyright (c) 2018>
 *
 * Jansson is free software; you can redistribute it and/or modify
 * it under the terms of the MIT license. See LICENSE for details.
 */

#ifndef UTIL_H
#define UTIL_H

#define max(a, b)  ((a) > (b) ? (a) : (b))

#endif
